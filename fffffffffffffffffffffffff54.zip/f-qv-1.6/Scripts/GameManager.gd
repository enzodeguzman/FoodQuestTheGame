extends Node

var r_locked := false

func lock_r():
	r_locked = true
	await get_tree().create_timer(5.0).timeout
	r_locked = false
