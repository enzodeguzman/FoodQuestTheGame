extends Control


@onready var label = $Label
@onready var timer = $Timer
var second
var minute 
