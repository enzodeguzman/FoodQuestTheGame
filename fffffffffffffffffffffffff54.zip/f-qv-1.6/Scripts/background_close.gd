extends Parallax2D

var fixed_y: float

func _ready():
	fixed_y = position.y

func _process(_delta):
	position.y = fixed_y
