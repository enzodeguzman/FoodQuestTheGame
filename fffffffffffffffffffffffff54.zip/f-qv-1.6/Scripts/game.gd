extends Node2D

@onready var transition = $TransitionLayer/PixelTransition
@onready var transition_sound = $TransitionSound
@onready var music = $AudioStreamPlayer


func _ready():
	
	music.volume_db = -80.0
	music.play()

	
	transition_sound.play()

	
	var music_tween = create_tween()
	music_tween.set_trans(Tween.TRANS_QUAD)
	music_tween.set_ease(Tween.EASE_OUT)

	music_tween.tween_property(
		music,
		"volume_db",
		0.0,
		1.1
	)

	
	await transition.reverse_transition()
