extends Control

@onready var color_rect = $ColorRect
@onready var shader_material = color_rect.material


func _ready():
	visible = false
	shader_material.set_shader_parameter("progress", 0.0)


func play_transition():
	visible = true

	shader_material.set_shader_parameter("progress", 0.0)

	var tween = create_tween()

	tween.set_trans(Tween.TRANS_QUAD)
	tween.set_ease(Tween.EASE_IN)

	tween.tween_method(
		set_progress,
		0.0,
		1.0,
		1.1
	)

	await tween.finished

	shader_material.set_shader_parameter("progress", 1.0)


func reverse_transition():
	visible = true

	
	shader_material.set_shader_parameter("progress", 1.0)

	var tween = create_tween()

	
	tween.set_trans(Tween.TRANS_QUAD)
	tween.set_ease(Tween.EASE_OUT)

	tween.tween_method(
		set_progress,
		1.0,
		0.0,
		1.1
	)

	await tween.finished

	visible = false


func set_progress(value):
	shader_material.set_shader_parameter("progress", value)
