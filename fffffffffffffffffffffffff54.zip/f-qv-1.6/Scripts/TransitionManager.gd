extends Node

var reverse_on_load := false
