extends Area2D

var restarting := false

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _process(_delta: float) -> void:
	if Input.is_key_pressed(KEY_R) and not restarting and not GameManager.r_locked:
		restart_level()

func _on_body_entered(body: Node) -> void:
	if body == get_tree().current_scene.get_node("Player") and not restarting:
		restart_level()

func restart_level() -> void:
	restarting = true
	GameManager.lock_r()

	var transition = get_tree().current_scene.get_node("TransitionLayer/PixelTransition")
	await transition.play_transition()

	get_tree().reload_current_scene()
