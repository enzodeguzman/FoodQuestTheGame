extends Control

@onready var credits_text = $CreditsText
@onready var return_text = $ReturnText
@onready var music = $Music
@onready var transition_sound = $TransitionSound

var scroll_speed := 30.0
var returning := false
var start_y: float

func _ready() -> void:
	start_y = credits_text.position.y

	music.volume_db = -80.0
	music.play()

	var music_tween = create_tween()
	music_tween.set_trans(Tween.TRANS_QUAD)
	music_tween.set_ease(Tween.EASE_IN_OUT)
	music_tween.tween_property(music, "volume_db", 0.0, 2.0)

	return_text.modulate.a = 0.0

	var tooltip_tween = create_tween()
	tooltip_tween.tween_interval(3.0)
	tooltip_tween.tween_property(return_text, "modulate:a", 1.0, 0.6)

func _process(delta: float) -> void:
	if not returning:
		credits_text.position.y -= scroll_speed * delta

		if credits_text.position.y < -credits_text.size.y:
			credits_text.position.y = start_y

	if Input.is_key_pressed(KEY_ESCAPE) and not returning:
		returning = true
		return_to_menu()

func return_to_menu() -> void:
	transition_sound.play()

	var transition = $TransitionLayer/PixelTransition

	await transition.play_transition()

	await get_tree().create_timer(1.2).timeout

	TransitionManager.reverse_on_load = true

	get_tree().change_scene_to_file("res://Scenes/MainMenu.tscn")
