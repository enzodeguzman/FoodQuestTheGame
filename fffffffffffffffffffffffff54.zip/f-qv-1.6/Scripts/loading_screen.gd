extends Control

@onready var loading_text = $LoadingText


func _ready():
	loading_text.modulate.a = 0.0

	var fade_in = create_tween()
	fade_in.tween_property(loading_text, "modulate:a", 1.0, 0.5)

	await fade_in.finished

	var dots = 1

	for i in range(11):
		loading_text.text = "LOADING " + ".".repeat(dots)

		await get_tree().create_timer(0.45).timeout

		dots += 1

		if dots > 3:
			dots = 1

	var fade_out = create_tween()
	fade_out.tween_property(loading_text, "modulate:a", 0.0, 0.5)

	await fade_out.finished

	get_tree().change_scene_to_file("res://Scenes/Game.tscn")
