extends Control

@onready var music = $AudioStreamPlayer
@onready var transition_sound = $TransitionSound
@onready var transition = $TransitionLayer/PixelTransition

func _ready() -> void:
	if TransitionManager.reverse_on_load:
		await get_tree().process_frame
		await transition.reverse_transition()
		TransitionManager.reverse_on_load = false

func _on_button_pressed():
	transition_sound.play()

	var music_tween = create_tween()
	music_tween.set_trans(Tween.TRANS_QUAD)
	music_tween.set_ease(Tween.EASE_IN_OUT)

	music_tween.tween_property(
		music,
		"volume_db",
		-80.0,
		1.1
	)

	await transition.play_transition()

	get_tree().change_scene_to_file("res://Scenes/LoadingScreen.tscn")

func _on_credits_button_pressed():
	transition_sound.play()

	var music_tween = create_tween()
	music_tween.set_trans(Tween.TRANS_QUAD)
	music_tween.set_ease(Tween.EASE_IN_OUT)

	music_tween.tween_property(
		music,
		"volume_db",
		-80.0,
		1.1
	)

	await transition.play_transition()

	get_tree().change_scene_to_file("res://Scenes/Credits.tscn")
