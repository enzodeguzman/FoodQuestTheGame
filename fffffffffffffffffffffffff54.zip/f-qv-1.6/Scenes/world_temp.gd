extends TileMapLayer

static var persistent_y_offset: float = 0.0

func _ready() -> void:

	position.y -= persistent_y_offset
	print("WorldTEMP loaded")

func _unhandled_input(event: InputEvent) -> void:

	if event is InputEventKey and event.pressed and not event.is_echo() and event.keycode == KEY_R:
		print("timer test")
		trigger_delayed_movement()

func trigger_delayed_movement() -> void:

	await get_tree().create_timer(1.0).timeout
	

	var tile_height: float = 16.0
	if tile_set:
		tile_height = tile_set.tile_size.y
	var total_pixels_up: float = 100 * tile_height
	

	persistent_y_offset += total_pixels_up
	print("100 tiles moved")
	

	get_tree().reload_current_scene()
