extends CharacterBody2D

const MAX_SPEED = 280.0
const GROUND_ACCELERATION = 2600.0
const GROUND_DECELERATION = 2200.0
const AIR_ACCELERATION = 1600.0
const AIR_DECELERATION = 350.0

const JUMP_VELOCITY = -550.0
const GRAVITY = 1400.0

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y += GRAVITY * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	var direction := Input.get_axis("ui_left", "ui_right")

	if direction != 0:
		if is_on_floor():
			velocity.x = move_toward(
				velocity.x,
				direction * MAX_SPEED,
				GROUND_ACCELERATION * delta
			)
		else:
			velocity.x = move_toward(
				velocity.x,
				direction * MAX_SPEED,
				AIR_ACCELERATION * delta
			)
	else:
		if is_on_floor():
			velocity.x = move_toward(
				velocity.x,
				0,
				GROUND_DECELERATION * delta
			)
		else:
			velocity.x = move_toward(
				velocity.x,
				0,
				AIR_DECELERATION * delta
			)

	move_and_slide()
